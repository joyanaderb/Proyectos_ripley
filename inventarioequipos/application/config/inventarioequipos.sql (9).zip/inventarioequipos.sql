-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 20-05-2021 a las 01:36:00
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `inventarioequipos`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `autores`
-- 

CREATE TABLE `autores` (
  `Id_autor` int(11) NOT NULL auto_increment,
  `Id_libro` int(11) NOT NULL,
  `Nombre` varchar(40) NOT NULL,
  `Activo` int(1) NOT NULL default '1',
  PRIMARY KEY  (`Id_autor`),
  KEY `FK_autores_libros` (`Id_libro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `autores`
-- 


-- --------------------------------------------------------

-- 
-- Estructura Stand-in para la vista `equiposdisponibles`
-- 
CREATE TABLE `equiposdisponibles` (
`total` bigint(21)
);
-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `estadoslibro`
-- 

CREATE TABLE `estadoslibro` (
  `id` int(11) NOT NULL auto_increment,
  `descripcion` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `estadoslibro`
-- 

INSERT INTO `estadoslibro` VALUES (1, 'Prestado');
INSERT INTO `estadoslibro` VALUES (2, 'Disponible');
INSERT INTO `estadoslibro` VALUES (3, 'Extraviado');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `facultades`
-- 

CREATE TABLE `facultades` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- 
-- Volcar la base de datos para la tabla `facultades`
-- 

INSERT INTO `facultades` VALUES (9, 'EN SERVICIO TECNICO');
INSERT INTO `facultades` VALUES (10, 'EN FUNCIONAMIENTO');
INSERT INTO `facultades` VALUES (11, 'EN PROCESO DE FORMATEAO');
INSERT INTO `facultades` VALUES (12, 'PENDIENTE DE SERVICIO TECNICO');
INSERT INTO `facultades` VALUES (13, 'IRREPARABLE');
INSERT INTO `facultades` VALUES (14, 'ROBADO');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `lectores`
-- 

CREATE TABLE `lectores` (
  `id_lector` int(11) NOT NULL auto_increment,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `dni` varchar(10) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `id_tipolector` int(11) NOT NULL,
  PRIMARY KEY  (`id_lector`),
  UNIQUE KEY `dni` (`dni`),
  KEY `id_tipolector` (`id_tipolector`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Volcar la base de datos para la tabla `lectores`
-- 

INSERT INTO `lectores` VALUES (2, 'juan carlos', 'perez alarcon', '45454545', '565656', 'Cale Primavera 430', 1, 1);
INSERT INTO `lectores` VALUES (3, 'yony', 'miguel', '45454548', '', 'miramar 3434', 1, 1);
INSERT INTO `lectores` VALUES (4, 'melisa', 'chacez', '45454546', '121121', 'Mirave 450', 1, 1);
INSERT INTO `lectores` VALUES (8, 'Javier', 'Nunez', '7580563-2', '971836195', 'loslunes', 1, 2);
INSERT INTO `lectores` VALUES (10, 'Javier', 'Oyazun', '17478040-4', '971836195', 'gfdgfd', 1, 1);
INSERT INTO `lectores` VALUES (11, 'Javier', 'Oayander', '18979625-5', '', 'fdfggf', 1, 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `libros`
-- 

CREATE TABLE `libros` (
  `id_libro` int(11) NOT NULL auto_increment,
  `codigo_libro` varchar(20) NOT NULL,
  `titulo_libro` varchar(150) NOT NULL,
  `subtitulo_libro` varchar(250) NOT NULL,
  `autor_libro` varchar(150) NOT NULL,
  `publicacion_libro` year(4) NOT NULL,
  `editorial_libro` varchar(250) NOT NULL,
  `ediccion_libro` varchar(250) NOT NULL,
  `idioma_libro` varchar(200) NOT NULL,
  `ejemplares_libro` int(11) NOT NULL,
  `prestados_libro` varchar(10) NOT NULL,
  `imagen_libro` varchar(250) NOT NULL,
  `id_facultad` int(11) NOT NULL,
  `isbn_libro` varchar(200) NOT NULL,
  PRIMARY KEY  (`id_libro`),
  KEY `id_facultad` (`id_facultad`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=466 ;

-- 
-- Volcar la base de datos para la tabla `libros`
-- 

INSERT INTO `libros` VALUES (1, '1', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 0, '0', 'default-book.png', 12, 'NXH38AL03392005E493400');
INSERT INTO `libros` VALUES (2, '2', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '4GB', '', '', 0, '0', 'default-book.png', 12, 'NXH38AL033920071F73400');
INSERT INTO `libros` VALUES (3, '3', 'HP', '500', 'HP Laptop 15-da0039la', 2019, '4GB', '', '', 0, '0', 'default-book.png', 12, 'CND9204J71');
INSERT INTO `libros` VALUES (4, '4', 'HP', '500', 'HP Laptop 15-da0039la', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, 'CND9204KJ8');
INSERT INTO `libros` VALUES (5, '5', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '4GB', '', '', 0, '0', 'default-book.png', 13, 'NXH38AL03392005F3C3400');
INSERT INTO `libros` VALUES (6, '6', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160QN0');
INSERT INTO `libros` VALUES (7, '7', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160S9T');
INSERT INTO `libros` VALUES (8, '8', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160QQC');
INSERT INTO `libros` VALUES (9, '9', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160QVR');
INSERT INTO `libros` VALUES (10, '10', 'HP', '500', 'HP ?15-da0082la', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, 'CND023392S');
INSERT INTO `libros` VALUES (11, '11', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 13, '5CG0160S22');
INSERT INTO `libros` VALUES (12, '12', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 12, '5CG0160SRC');
INSERT INTO `libros` VALUES (13, '13', 'HP', '500', 'HP ?15-da0082la', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, 'CND02339DH');
INSERT INTO `libros` VALUES (14, '14', 'HP', '500', 'HP ?15-da0082la', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND023390D');
INSERT INTO `libros` VALUES (15, '15', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S5Q');
INSERT INTO `libros` VALUES (16, '16', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D227S');
INSERT INTO `libros` VALUES (17, '17', 'HP', '500', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RTT');
INSERT INTO `libros` VALUES (18, '18', 'HP', '500', 'HP Laptop 15-da0039la', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204K2R');
INSERT INTO `libros` VALUES (20, '20', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S6X');
INSERT INTO `libros` VALUES (21, '21', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160QVQ');
INSERT INTO `libros` VALUES (22, '22', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S39');
INSERT INTO `libros` VALUES (23, '23', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T4L');
INSERT INTO `libros` VALUES (24, '24', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S99');
INSERT INTO `libros` VALUES (25, '25', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 0, '1', 'default-book.png', 10, '5CG0160SMB');
INSERT INTO `libros` VALUES (26, '26', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T07');
INSERT INTO `libros` VALUES (27, '27', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SG6');
INSERT INTO `libros` VALUES (28, '28', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T0V');
INSERT INTO `libros` VALUES (29, '29', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 0, '1', 'default-book.png', 10, '5CG0160QMB');
INSERT INTO `libros` VALUES (31, '31', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160R2H');
INSERT INTO `libros` VALUES (32, '32', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SXZ');
INSERT INTO `libros` VALUES (33, '33', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160QBF');
INSERT INTO `libros` VALUES (34, '34', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RV2');
INSERT INTO `libros` VALUES (35, '35', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T5H');
INSERT INTO `libros` VALUES (36, '36', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T6T');
INSERT INTO `libros` VALUES (37, '37', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160S67');
INSERT INTO `libros` VALUES (38, '38', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 12, '5CG0160QB1');
INSERT INTO `libros` VALUES (39, '39', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S9X');
INSERT INTO `libros` VALUES (464, '451', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160SCW');
INSERT INTO `libros` VALUES (403, '415', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5GC016OQLD');
INSERT INTO `libros` VALUES (42, '42', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RTJ');
INSERT INTO `libros` VALUES (43, '43', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MDW');
INSERT INTO `libros` VALUES (44, '44', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND02339VV');
INSERT INTO `libros` VALUES (45, '45', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND02339H4');
INSERT INTO `libros` VALUES (46, '46', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D1SG');
INSERT INTO `libros` VALUES (48, '48', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2DC');
INSERT INTO `libros` VALUES (49, '49', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0233B0H');
INSERT INTO `libros` VALUES (50, '50', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0204J9X');
INSERT INTO `libros` VALUES (51, '51', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02339PN');
INSERT INTO `libros` VALUES (52, '52', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0204KSP');
INSERT INTO `libros` VALUES (53, '53', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025C2F4');
INSERT INTO `libros` VALUES (54, '54', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND023392U ');
INSERT INTO `libros` VALUES (55, '55', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0275M8F');
INSERT INTO `libros` VALUES (56, '56', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D27V');
INSERT INTO `libros` VALUES (57, '57', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D2JH');
INSERT INTO `libros` VALUES (58, '58', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0204JK6');
INSERT INTO `libros` VALUES (59, '59', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 0, '2', 'default-book.png', 10, 'CND025D22B');
INSERT INTO `libros` VALUES (60, '60', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D27T');
INSERT INTO `libros` VALUES (61, '61', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D26Y');
INSERT INTO `libros` VALUES (62, '62', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MRC');
INSERT INTO `libros` VALUES (63, '63', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0275MQS');
INSERT INTO `libros` VALUES (64, '64', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D1VV');
INSERT INTO `libros` VALUES (65, '65', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D28W');
INSERT INTO `libros` VALUES (66, '66', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND025D2QB');
INSERT INTO `libros` VALUES (67, '67', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, 'CND0233B1M');
INSERT INTO `libros` VALUES (68, '68', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2D8');
INSERT INTO `libros` VALUES (69, '69', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920059be3400');
INSERT INTO `libros` VALUES (70, '70', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL033920060CD3400');
INSERT INTO `libros` VALUES (71, '71', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL033920073743400');
INSERT INTO `libros` VALUES (72, '72', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL033920056D73400');
INSERT INTO `libros` VALUES (73, '73', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920075923400');
INSERT INTO `libros` VALUES (74, '74', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392009DC83400');
INSERT INTO `libros` VALUES (75, '75', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005BA03400');
INSERT INTO `libros` VALUES (76, '76', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392005fc73400');
INSERT INTO `libros` VALUES (77, '77', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920080FB3400');
INSERT INTO `libros` VALUES (78, '78', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL0339200744C3400');
INSERT INTO `libros` VALUES (79, '79', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072903400');
INSERT INTO `libros` VALUES (80, '80', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392007B843400');
INSERT INTO `libros` VALUES (81, '81', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL033920059D23400');
INSERT INTO `libros` VALUES (82, '82', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 0, '0', 'default-book.png', 12, 'NXH38AL0339200732F3400');
INSERT INTO `libros` VALUES (85, '85', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '8GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160SC7');
INSERT INTO `libros` VALUES (86, '86', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160TOQ');
INSERT INTO `libros` VALUES (87, '87', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160SP3');
INSERT INTO `libros` VALUES (89, '89', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QTP');
INSERT INTO `libros` VALUES (90, '90', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QB2');
INSERT INTO `libros` VALUES (91, '91', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QVK');
INSERT INTO `libros` VALUES (92, '92', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T5Q');
INSERT INTO `libros` VALUES (93, '93', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QB5');
INSERT INTO `libros` VALUES (94, '94', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QBY');
INSERT INTO `libros` VALUES (95, '95', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160RT7');
INSERT INTO `libros` VALUES (96, '96', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SLN');
INSERT INTO `libros` VALUES (97, '97', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SZR');
INSERT INTO `libros` VALUES (98, '98', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RZ1');
INSERT INTO `libros` VALUES (99, '99', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RZQ');
INSERT INTO `libros` VALUES (100, '100', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QV9');
INSERT INTO `libros` VALUES (101, '101', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SYL');
INSERT INTO `libros` VALUES (102, '102', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SF2');
INSERT INTO `libros` VALUES (103, '103', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q9K');
INSERT INTO `libros` VALUES (104, '104', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SFM');
INSERT INTO `libros` VALUES (105, '105', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QKV');
INSERT INTO `libros` VALUES (106, '106', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SY9');
INSERT INTO `libros` VALUES (107, '107', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQB');
INSERT INTO `libros` VALUES (109, '109', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SYR');
INSERT INTO `libros` VALUES (110, '110', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q88');
INSERT INTO `libros` VALUES (112, '112', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SL9');
INSERT INTO `libros` VALUES (113, '113', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QNS');
INSERT INTO `libros` VALUES (114, '114', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SDF');
INSERT INTO `libros` VALUES (115, '115', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QMC');
INSERT INTO `libros` VALUES (116, '116', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QKJ');
INSERT INTO `libros` VALUES (400, '402', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QNL');
INSERT INTO `libros` VALUES (118, '118', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SCQ');
INSERT INTO `libros` VALUES (119, '119', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S2L');
INSERT INTO `libros` VALUES (120, '120', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QTG');
INSERT INTO `libros` VALUES (121, '121', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SYZ');
INSERT INTO `libros` VALUES (122, '122', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S2K');
INSERT INTO `libros` VALUES (123, '123', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SF8');
INSERT INTO `libros` VALUES (124, '124', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SDH');
INSERT INTO `libros` VALUES (125, '125', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SFQ');
INSERT INTO `libros` VALUES (126, '126', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QDC');
INSERT INTO `libros` VALUES (127, '127', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q89');
INSERT INTO `libros` VALUES (128, '128', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '0', 'default-book.png', 10, '5CG0160SCR');
INSERT INTO `libros` VALUES (129, '129', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q7F');
INSERT INTO `libros` VALUES (130, '130', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QP9');
INSERT INTO `libros` VALUES (131, '131', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q9W');
INSERT INTO `libros` VALUES (132, '132', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QDS');
INSERT INTO `libros` VALUES (133, '133', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QNG');
INSERT INTO `libros` VALUES (134, '134', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160R1L');
INSERT INTO `libros` VALUES (135, '135', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SLX');
INSERT INTO `libros` VALUES (136, '136', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SQC');
INSERT INTO `libros` VALUES (137, '137', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QL8');
INSERT INTO `libros` VALUES (138, '138', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S9M');
INSERT INTO `libros` VALUES (139, '139', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RYJ');
INSERT INTO `libros` VALUES (463, '430', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275M97');
INSERT INTO `libros` VALUES (142, '142', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QN7');
INSERT INTO `libros` VALUES (143, '143', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QPQ');
INSERT INTO `libros` VALUES (144, '144', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SCV');
INSERT INTO `libros` VALUES (145, '145', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QKC');
INSERT INTO `libros` VALUES (146, '146', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QTQ');
INSERT INTO `libros` VALUES (147, '147', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQ9');
INSERT INTO `libros` VALUES (148, '148', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q8G');
INSERT INTO `libros` VALUES (149, '149', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SDG');
INSERT INTO `libros` VALUES (151, '151', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SR5');
INSERT INTO `libros` VALUES (152, '152', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SXT');
INSERT INTO `libros` VALUES (153, '153', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QCN');
INSERT INTO `libros` VALUES (154, '154', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SM1');
INSERT INTO `libros` VALUES (155, '155', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SY6');
INSERT INTO `libros` VALUES (156, '156', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SQ5');
INSERT INTO `libros` VALUES (402, '413', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2LD');
INSERT INTO `libros` VALUES (158, '158', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 0, '0', 'default-book.png', 11, '5CG0160T6K');
INSERT INTO `libros` VALUES (159, '159', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SDR');
INSERT INTO `libros` VALUES (160, '160', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QK2');
INSERT INTO `libros` VALUES (162, '162', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SPM');
INSERT INTO `libros` VALUES (164, '164', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SLM');
INSERT INTO `libros` VALUES (166, '166', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SRS');
INSERT INTO `libros` VALUES (167, '167', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RV6');
INSERT INTO `libros` VALUES (168, '168', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QTL');
INSERT INTO `libros` VALUES (404, '416', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160TGL');
INSERT INTO `libros` VALUES (171, '171', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QPS');
INSERT INTO `libros` VALUES (172, '172', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q85');
INSERT INTO `libros` VALUES (173, '173', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SLY');
INSERT INTO `libros` VALUES (405, '417', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S60');
INSERT INTO `libros` VALUES (175, '175', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQ7');
INSERT INTO `libros` VALUES (176, '176', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SFL');
INSERT INTO `libros` VALUES (178, '178', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T5M');
INSERT INTO `libros` VALUES (179, '179', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SDQ');
INSERT INTO `libros` VALUES (180, '180', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QLG');
INSERT INTO `libros` VALUES (182, '182', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG160SQK');
INSERT INTO `libros` VALUES (183, '183', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QNN');
INSERT INTO `libros` VALUES (184, '184', 'HP ', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T6S');
INSERT INTO `libros` VALUES (185, '185', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SPH');
INSERT INTO `libros` VALUES (186, '186', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02339MC');
INSERT INTO `libros` VALUES (187, '187', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0214283');
INSERT INTO `libros` VALUES (188, '188', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02338JX');
INSERT INTO `libros` VALUES (191, '191', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND023390P');
INSERT INTO `libros` VALUES (192, '192', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02339N6');
INSERT INTO `libros` VALUES (193, '193', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0233BLB');
INSERT INTO `libros` VALUES (194, '194', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0214263');
INSERT INTO `libros` VALUES (195, '195', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02339B3');
INSERT INTO `libros` VALUES (196, '196', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0233BGV');
INSERT INTO `libros` VALUES (197, '197', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND02339OD');
INSERT INTO `libros` VALUES (198, '198', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CNDO233B5Y');
INSERT INTO `libros` VALUES (200, '200', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND275MK2');
INSERT INTO `libros` VALUES (201, '201', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2M3');
INSERT INTO `libros` VALUES (203, '203', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275N8D');
INSERT INTO `libros` VALUES (204, '204', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MBK');
INSERT INTO `libros` VALUES (205, '205', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275N48');
INSERT INTO `libros` VALUES (207, '207', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D1WB');
INSERT INTO `libros` VALUES (208, '208', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D28T');
INSERT INTO `libros` VALUES (211, '211', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2JG');
INSERT INTO `libros` VALUES (212, '212', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D1XV');
INSERT INTO `libros` VALUES (213, '213', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D2CN');
INSERT INTO `libros` VALUES (216, '216', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND025D1WK');
INSERT INTO `libros` VALUES (218, '218', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MX1');
INSERT INTO `libros` VALUES (219, '219', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MB9');
INSERT INTO `libros` VALUES (220, '220', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MN7');
INSERT INTO `libros` VALUES (221, '221', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275NHK');
INSERT INTO `libros` VALUES (222, '222', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275N82');
INSERT INTO `libros` VALUES (223, '223', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MWN');
INSERT INTO `libros` VALUES (224, '224', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275NRJ');
INSERT INTO `libros` VALUES (406, '418', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SZW');
INSERT INTO `libros` VALUES (226, '226', 'HP ', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0275MZ6');
INSERT INTO `libros` VALUES (227, '227', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005DF83400');
INSERT INTO `libros` VALUES (228, '228', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200728E3400');
INSERT INTO `libros` VALUES (229, '229', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200720A3400');
INSERT INTO `libros` VALUES (230, '230', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072633400');
INSERT INTO `libros` VALUES (231, '231', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D063400');
INSERT INTO `libros` VALUES (232, '232', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009ED93400');
INSERT INTO `libros` VALUES (233, '233', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009E2F3400');
INSERT INTO `libros` VALUES (234, '234', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DF13400');
INSERT INTO `libros` VALUES (235, '235', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E8D3400');
INSERT INTO `libros` VALUES (236, '236', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DAC3400');
INSERT INTO `libros` VALUES (237, '237', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005EB73400');
INSERT INTO `libros` VALUES (238, '238', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200736D3400');
INSERT INTO `libros` VALUES (239, '239', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CBF3400');
INSERT INTO `libros` VALUES (240, '240', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E0C3400');
INSERT INTO `libros` VALUES (241, '241', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D413400');
INSERT INTO `libros` VALUES (242, '242', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005B9C3400');
INSERT INTO `libros` VALUES (243, '243', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CBC3400');
INSERT INTO `libros` VALUES (244, '244', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DC73400');
INSERT INTO `libros` VALUES (245, '245', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D3B3400');
INSERT INTO `libros` VALUES (246, '246', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005B463400');
INSERT INTO `libros` VALUES (247, '247', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005C973400');
INSERT INTO `libros` VALUES (248, '248', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E213400');
INSERT INTO `libros` VALUES (249, '249', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D543400');
INSERT INTO `libros` VALUES (250, '250', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D133400');
INSERT INTO `libros` VALUES (251, '251', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DEF3400');
INSERT INTO `libros` VALUES (252, '252', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005FC93400');
INSERT INTO `libros` VALUES (253, '253', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E843400');
INSERT INTO `libros` VALUES (254, '254', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920075643400');
INSERT INTO `libros` VALUES (255, '255', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392005F263400');
INSERT INTO `libros` VALUES (256, '256', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392005F263400');
INSERT INTO `libros` VALUES (257, '257', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009E4C3400');
INSERT INTO `libros` VALUES (258, '258', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920058DD3400');
INSERT INTO `libros` VALUES (259, '259', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072CE3400');
INSERT INTO `libros` VALUES (260, '260', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200734F3400');
INSERT INTO `libros` VALUES (262, '262', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DF23400');
INSERT INTO `libros` VALUES (263, '263', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009EB23400');
INSERT INTO `libros` VALUES (264, '264', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E5A3400');
INSERT INTO `libros` VALUES (265, '265', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005EB63400');
INSERT INTO `libros` VALUES (266, '266', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005C9A3400');
INSERT INTO `libros` VALUES (267, '267', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072EA3400');
INSERT INTO `libros` VALUES (268, '268', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005E133400');
INSERT INTO `libros` VALUES (269, '269', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200738D3400');
INSERT INTO `libros` VALUES (270, '270', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920071AD3400');
INSERT INTO `libros` VALUES (271, '271', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005C893400');
INSERT INTO `libros` VALUES (272, '272', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005FBB3400');
INSERT INTO `libros` VALUES (273, '273', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CD93400');
INSERT INTO `libros` VALUES (274, '274', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392007B843400');
INSERT INTO `libros` VALUES (275, '275', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL00403517BA23400');
INSERT INTO `libros` VALUES (276, '276', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL00403516DA23400');
INSERT INTO `libros` VALUES (277, '277', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL00403516E303400');
INSERT INTO `libros` VALUES (278, '278', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL00403517B2C3400');
INSERT INTO `libros` VALUES (279, '279', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200730F3400');
INSERT INTO `libros` VALUES (280, '280', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073493400');
INSERT INTO `libros` VALUES (281, '281', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KX2');
INSERT INTO `libros` VALUES (282, '282', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920060D33400');
INSERT INTO `libros` VALUES (283, '283', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204MT3');
INSERT INTO `libros` VALUES (407, '419', 'ACER', '500GB', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38ALO3392005B983400');
INSERT INTO `libros` VALUES (286, '286', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200718D3400');
INSERT INTO `libros` VALUES (408, '420', 'ACER', '500GB', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005A573400');
INSERT INTO `libros` VALUES (289, '289', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200601D3400');
INSERT INTO `libros` VALUES (290, '290', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005ED13400');
INSERT INTO `libros` VALUES (291, '291', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KBT');
INSERT INTO `libros` VALUES (292, '292', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072023400');
INSERT INTO `libros` VALUES (293, '293', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072403400');
INSERT INTO `libros` VALUES (294, '294', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072A23400');
INSERT INTO `libros` VALUES (295, '295', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KJB');
INSERT INTO `libros` VALUES (296, '296', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920058423400');
INSERT INTO `libros` VALUES (297, '297', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 11, 'CND9204KTW');
INSERT INTO `libros` VALUES (298, '298', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204J6Z');
INSERT INTO `libros` VALUES (299, '299', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009E203400');
INSERT INTO `libros` VALUES (300, '300', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CB53400');
INSERT INTO `libros` VALUES (301, '301', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073F33400');
INSERT INTO `libros` VALUES (302, '302', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KHS');
INSERT INTO `libros` VALUES (303, '303', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204JD6');
INSERT INTO `libros` VALUES (304, '304', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DCB3400');
INSERT INTO `libros` VALUES (305, '305', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005EDE3400');
INSERT INTO `libros` VALUES (306, '306', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920059ED3400');
INSERT INTO `libros` VALUES (307, '307', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND919166X');
INSERT INTO `libros` VALUES (460, '460', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 1, '0', 'default-book.png', 11, 'CND9204KLW');
INSERT INTO `libros` VALUES (310, '310', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005C323400');
INSERT INTO `libros` VALUES (312, '312', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005FFE3400');
INSERT INTO `libros` VALUES (313, '313', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920060553400');
INSERT INTO `libros` VALUES (462, '481', 'ACER', '500GB', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392005D9A3400');
INSERT INTO `libros` VALUES (315, '315', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200611C3400');
INSERT INTO `libros` VALUES (401, '412', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q8Q');
INSERT INTO `libros` VALUES (317, '317', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005F093400');
INSERT INTO `libros` VALUES (318, '318', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072B33400');
INSERT INTO `libros` VALUES (319, '319', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005EE93400');
INSERT INTO `libros` VALUES (320, '320', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DC33400');
INSERT INTO `libros` VALUES (321, '321', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005FE93400');
INSERT INTO `libros` VALUES (322, '322', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200605F3400');
INSERT INTO `libros` VALUES (323, '323', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KD0');
INSERT INTO `libros` VALUES (324, '324', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920059B33400');
INSERT INTO `libros` VALUES (325, '325', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CB33400');
INSERT INTO `libros` VALUES (326, '326', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073643400');
INSERT INTO `libros` VALUES (327, '327', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920056B83400');
INSERT INTO `libros` VALUES (328, '328', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920071F43400');
INSERT INTO `libros` VALUES (329, '329', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009D673400');
INSERT INTO `libros` VALUES (330, '330', 'HP', '500', '15-DA1094LA', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'CND9204KB4');
INSERT INTO `libros` VALUES (331, '331', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920056783400');
INSERT INTO `libros` VALUES (332, '332', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920057A03400');
INSERT INTO `libros` VALUES (333, '333', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072883400');
INSERT INTO `libros` VALUES (334, '334', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DA93400');
INSERT INTO `libros` VALUES (335, '335', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DF53400');
INSERT INTO `libros` VALUES (336, '336', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005B893400');
INSERT INTO `libros` VALUES (337, '337', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920081053400');
INSERT INTO `libros` VALUES (338, '338', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920076BD3400');
INSERT INTO `libros` VALUES (339, '339', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200602E3400');
INSERT INTO `libros` VALUES (340, '340', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200578D3400');
INSERT INTO `libros` VALUES (341, '341', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXH38AL03392005C493400');
INSERT INTO `libros` VALUES (342, '342', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072EC3400');
INSERT INTO `libros` VALUES (343, '343', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200601F3400');
INSERT INTO `libros` VALUES (344, '344', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920056713400');
INSERT INTO `libros` VALUES (345, '345', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009D793400');
INSERT INTO `libros` VALUES (346, '346', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920056123400');
INSERT INTO `libros` VALUES (347, '347', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200605C3400');
INSERT INTO `libros` VALUES (348, '348', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005ED43400');
INSERT INTO `libros` VALUES (349, '349', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073CB3400');
INSERT INTO `libros` VALUES (350, '350', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005F203400');
INSERT INTO `libros` VALUES (351, '351', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005B6F3400');
INSERT INTO `libros` VALUES (352, '352', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RVQ');
INSERT INTO `libros` VALUES (353, '353', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200741E3400');
INSERT INTO `libros` VALUES (354, '354', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005A703400');
INSERT INTO `libros` VALUES (461, '480', 'HP', '500GB', 'HP Laptop 14-CK0027LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 14, '5CG0160SXS');
INSERT INTO `libros` VALUES (356, '356', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200739D3400');
INSERT INTO `libros` VALUES (357, '357', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072283400');
INSERT INTO `libros` VALUES (358, '358', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D003400');
INSERT INTO `libros` VALUES (359, '359', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T0D');
INSERT INTO `libros` VALUES (360, '360', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SPK');
INSERT INTO `libros` VALUES (361, '361', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005D4F3400');
INSERT INTO `libros` VALUES (362, '362', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920071BE3400');
INSERT INTO `libros` VALUES (364, '364', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009D653400');
INSERT INTO `libros` VALUES (450, '450', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 0, '0', 'default-book.png', 12, 'CND0275NRW');
INSERT INTO `libros` VALUES (367, '367', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QW7');
INSERT INTO `libros` VALUES (368, '368', 'HP', '500', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND0233B62');
INSERT INTO `libros` VALUES (369, '369', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005ED73400');
INSERT INTO `libros` VALUES (370, '370', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392009DEA3400');
INSERT INTO `libros` VALUES (371, '371', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920072993400');
INSERT INTO `libros` VALUES (372, '372', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S31');
INSERT INTO `libros` VALUES (373, '373', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160T0H');
INSERT INTO `libros` VALUES (374, '374', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160R28');
INSERT INTO `libros` VALUES (375, '375', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQ0');
INSERT INTO `libros` VALUES (412, '427', 'ACER', '500GB', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '0', 'default-book.png', 10, 'NXHSEAL00403517S93400');
INSERT INTO `libros` VALUES (377, '377', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SP1');
INSERT INTO `libros` VALUES (378, '378', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQH');
INSERT INTO `libros` VALUES (379, '379', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392005CA73400');
INSERT INTO `libros` VALUES (380, '380', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160Q8J');
INSERT INTO `libros` VALUES (381, '381', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S2F');
INSERT INTO `libros` VALUES (382, '382', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160RYG');
INSERT INTO `libros` VALUES (383, '383', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160QQF');
INSERT INTO `libros` VALUES (384, '384', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CD6521QQK');
INSERT INTO `libros` VALUES (386, '386', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SL3');
INSERT INTO `libros` VALUES (387, '387', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160S6R');
INSERT INTO `libros` VALUES (388, '388', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SY2');
INSERT INTO `libros` VALUES (389, '389', 'HP', '500', 'HP Laptop 14-CK0027LA ', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, '5CG0160SZM');
INSERT INTO `libros` VALUES (390, '390', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920071C83400');
INSERT INTO `libros` VALUES (391, '391', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920060233400');
INSERT INTO `libros` VALUES (392, '392', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL0339200732B3400');
INSERT INTO `libros` VALUES (393, '393', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL03392006D9A3400');
INSERT INTO `libros` VALUES (394, '394', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073423400');
INSERT INTO `libros` VALUES (465, '473', 'HP', '500GB', '15-DA1094LA', 2019, '4GB', '', '', 1, '1', 'default-book.png', 10, 'CND023392Q');
INSERT INTO `libros` VALUES (396, '396', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL004035168043400');
INSERT INTO `libros` VALUES (397, '397', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920058D33400');
INSERT INTO `libros` VALUES (398, '398', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXH38AL033920073B73400');
INSERT INTO `libros` VALUES (399, '399', 'ACER', '500', 'ASPIRE 3 A315-35', 2019, '8GB', '', '', 1, '1', 'default-book.png', 10, 'NXHSEAL004035168FB3400');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `menus`
-- 

CREATE TABLE `menus` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) default NULL,
  `link` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `menus`
-- 

INSERT INTO `menus` VALUES (1, 'Inicio', 'backend/dashboard');
INSERT INTO `menus` VALUES (2, 'Ejecutivos', 'backend/ejecutivos');
INSERT INTO `menus` VALUES (3, 'Equipos', 'backend/equipos');
INSERT INTO `menus` VALUES (4, 'Asignar equipos', 'backend/prestamos/add');
INSERT INTO `menus` VALUES (5, 'Asignaciones vigentes', 'backend/prestamos/pending');
INSERT INTO `menus` VALUES (6, 'Historial Asignaciones', 'backend/prestamos/all');
INSERT INTO `menus` VALUES (7, 'Permisos Usuarios', 'backend/permisos');
INSERT INTO `menus` VALUES (9, 'Usuarios', 'backend/usuarios');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `permisos`
-- 

CREATE TABLE `permisos` (
  `id` int(11) NOT NULL auto_increment,
  `menu_id` int(11) default NULL,
  `rol_id` int(11) default NULL,
  `read` int(11) default NULL,
  `insert` int(11) default NULL,
  `update` int(11) default NULL,
  `delete` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_menus_idx` (`menu_id`),
  KEY `fk_rol_idx` (`rol_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

-- 
-- Volcar la base de datos para la tabla `permisos`
-- 

INSERT INTO `permisos` VALUES (20, 2, 2, 1, 0, 0, 0);
INSERT INTO `permisos` VALUES (22, 4, 2, 1, 0, 1, 0);
INSERT INTO `permisos` VALUES (23, 5, 1, 0, 0, 0, 0);
INSERT INTO `permisos` VALUES (24, 6, 2, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (25, 5, 2, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (26, 2, 1, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (27, 3, 1, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (28, 4, 1, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (30, 6, 1, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (35, 7, 1, 1, 1, 1, 1);
INSERT INTO `permisos` VALUES (36, 9, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `prestamos`
-- 

CREATE TABLE `prestamos` (
  `id` int(11) NOT NULL auto_increment,
  `id_libro` int(11) NOT NULL,
  `id_lector` int(11) NOT NULL,
  `fechaprestamo` varchar(100) NOT NULL,
  `fechadevolucion` varchar(100) NOT NULL,
  `estado_prestamo` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_libro` (`id_libro`),
  KEY `id_lector` (`id_lector`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=360 ;

-- 
-- Volcar la base de datos para la tabla `prestamos`
-- 

INSERT INTO `prestamos` VALUES (1, 399, 5693, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (2, 86, 5536, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (3, 87, 5165, '01/03/2021', '14/05/2021', 1);
INSERT INTO `prestamos` VALUES (4, 89, 5495, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (5, 90, 5503, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (6, 91, 5797, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (7, 92, 5486, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (8, 93, 26694646, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (9, 94, 5203, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (10, 95, 5532, '01/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (11, 96, 5531, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (12, 97, 5526, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (13, 98, 5499, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (14, 99, 5794, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (15, 100, 26694672, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (16, 101, 26694650, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (17, 102, 5541, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (18, 103, 5527, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (19, 104, 5756, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (20, 105, 5498, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (21, 106, 26694651, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (22, 107, 5489, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (23, 109, 5785, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (24, 110, 5407, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (25, 112, 5553, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (26, 113, 5471, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (27, 114, 5481, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (28, 115, 5752, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (29, 116, 5751, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (30, 118, 5806, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (31, 119, 26694671, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (32, 120, 5476, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (33, 121, 5482, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (34, 122, 5484, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (35, 123, 5475, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (36, 124, 5782, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (37, 125, 5556, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (38, 126, 26694673, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (39, 127, 5542, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (40, 128, 5554, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (41, 129, 5560, '01/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (42, 130, 5559, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (43, 131, 26694652, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (44, 132, 5466, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (45, 133, 5474, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (46, 134, 5716, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (47, 136, 26694675, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (48, 137, 26694674, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (49, 138, 5508, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (50, 139, 5515, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (51, 141, 5808, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (52, 142, 5514, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (53, 143, 5516, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (54, 144, 5459, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (55, 145, 5460, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (56, 146, 26694677, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (57, 147, 5694, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (58, 148, 5202, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (59, 149, 5458, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (60, 151, 5504, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (61, 152, 5507, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (62, 153, 5512, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (63, 154, 5513, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (64, 155, 5519, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (65, 158, 5457, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (66, 159, 5722, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (67, 160, 5678, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (68, 162, 5720, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (69, 164, 5674, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (70, 166, 5692, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (71, 167, 5685, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (72, 168, 5680, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (73, 171, 5695, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (74, 172, 5793, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (75, 173, 5690, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (76, 175, 26694659, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (77, 176, 5713, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (78, 178, 5701, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (79, 179, 5702, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (80, 180, 5699, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (81, 182, 26694118, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (82, 183, 5704, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (83, 184, 5723, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (84, 185, 5451, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (85, 186, 5742, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (86, 187, 5737, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (87, 188, 5735, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (88, 191, 5734, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (89, 192, 5739, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (90, 193, 5738, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (91, 194, 5727, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (92, 195, 5731, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (93, 196, 5749, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (94, 197, 26694121, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (95, 198, 5783, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (96, 199, 5748, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (97, 200, 5754, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (98, 201, 5773, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (99, 203, 26694648, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (100, 204, 26694122, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (101, 205, 5746, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (102, 207, 5761, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (103, 208, 5766, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (104, 211, 5760, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (105, 212, 5765, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (106, 213, 5758, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (107, 216, 5253, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (108, 217, 26694117, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (109, 218, 5558, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (110, 219, 5788, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (111, 220, 26694657, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (112, 221, 26694667, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (113, 222, 26694668, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (114, 223, 5168, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (115, 224, 5687, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (116, 226, 5206, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (117, 227, 5133, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (118, 228, 5158, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (119, 229, 5233, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (120, 230, 5328, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (121, 231, 5196, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (122, 232, 5281, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (123, 233, 5234, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (124, 234, 5350, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (125, 235, 5293, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (126, 236, 5232, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (127, 237, 5335, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (128, 239, 5236, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (129, 240, 5264, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (130, 241, 5146, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (131, 242, 5130, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (132, 243, 5134, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (133, 244, 5154, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (134, 245, 5159, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (135, 246, 5167, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (136, 247, 5177, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (137, 248, 5188, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (138, 249, 5201, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (139, 250, 5211, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (140, 251, 5217, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (141, 252, 5221, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (142, 253, 5230, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (143, 254, 5235, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (144, 257, 5240, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (145, 258, 5242, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (146, 259, 5244, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (147, 260, 5269, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (148, 262, 5164, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (149, 263, 5214, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (150, 264, 5222, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (151, 265, 5225, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (152, 266, 5256, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (153, 267, 5257, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (154, 268, 5260, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (155, 269, 5265, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (156, 270, 5267, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (157, 271, 5268, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (158, 272, 5280, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (159, 273, 5290, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (160, 275, 26694699, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (161, 276, 26694700, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (162, 277, 26694701, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (163, 278, 26694703, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (164, 279, 5122, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (165, 281, 5132, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (166, 286, 5150, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (167, 288, 5171, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (168, 289, 5182, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (169, 290, 5184, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (170, 291, 5186, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (171, 292, 5189, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (172, 293, 5190, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (173, 294, 5191, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (174, 295, 5192, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (175, 296, 5195, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (176, 297, 5198, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (177, 298, 5209, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (178, 299, 5212, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (179, 300, 5218, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (180, 301, 5220, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (181, 302, 5224, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (182, 303, 5226, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (183, 304, 5227, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (184, 305, 5229, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (185, 306, 5239, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (186, 307, 5248, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (187, 310, 5255, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (188, 312, 5261, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (189, 313, 5262, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (190, 314, 5263, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (191, 314, 5263, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (192, 315, 5270, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (193, 317, 5272, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (194, 318, 5273, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (195, 319, 5275, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (196, 320, 5276, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (197, 321, 5277, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (198, 322, 5278, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (199, 323, 5284, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (200, 324, 5285, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (201, 325, 5288, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (202, 326, 5289, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (203, 327, 5291, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (204, 328, 5306, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (205, 329, 5317, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (206, 330, 5321, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (207, 331, 5322, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (208, 332, 5323, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (209, 333, 5330, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (210, 334, 5333, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (211, 335, 5338, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (212, 336, 5341, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (213, 337, 5343, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (214, 338, 5344, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (215, 339, 5345, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (216, 340, 5347, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (217, 341, 5348, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (218, 342, 5352, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (219, 343, 5355, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (220, 344, 5356, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (221, 345, 5358, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (222, 346, 5360, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (223, 347, 5361, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (224, 348, 5363, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (225, 349, 5386, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (226, 350, 5426, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (227, 351, 5429, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (228, 352, 5715, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (229, 353, 5436, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (230, 354, 5437, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (231, 355, 5438, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (232, 355, 5438, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (233, 356, 5442, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (234, 357, 5443, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (235, 358, 5444, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (236, 359, 5510, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (237, 360, 5709, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (238, 361, 26694706, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (239, 362, 26694707, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (240, 363, 26694708, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (241, 364, 26694709, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (242, 367, 5537, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (243, 368, 5726, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (244, 369, 5148, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (245, 370, 5354, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (246, 371, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (247, 372, 26694679, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (248, 373, 26694685, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (249, 374, 26694681, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (250, 377, 26694680, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (251, 378, 26694682, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (252, 379, 5449, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (253, 380, 26694689, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (254, 381, 26694688, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (255, 382, 26694692, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (256, 383, 5166, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (257, 384, 5131, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (258, 386, 26694693, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (259, 387, 26694691, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (260, 388, 26694690, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (261, 389, 26694687, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (262, 390, 5446, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (263, 391, 5454, '05/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (264, 392, 5448, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (265, 393, 5228, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (266, 394, 5453, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (267, 396, 26694702, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (268, 397, 5129, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (269, 398, 5447, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (270, 400, 5500, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (271, 401, 5717, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (272, 49, 5147, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (273, 402, 5799, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (274, 135, 5719, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (275, 156, 5800, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (276, 403, 5682, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (277, 404, 5494, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (278, 405, 26694666, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (279, 28, 5249, '19/04/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (280, 28, 5457, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (281, 406, 5544, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (282, 79, 5187, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (283, 280, 5123, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (284, 273, 5296, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (285, 282, 5141, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (286, 283, 5143, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (287, 407, 5162, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (288, 408, 5249, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (289, 409, 5250, '05/03/2021', '23/04/2021', 1);
INSERT INTO `prestamos` VALUES (290, 38, 5250, '19/04/2021', '23/04/2021', 1);
INSERT INTO `prestamos` VALUES (291, 391, 5258, '19/04/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (292, 410, 5171, '05/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (293, 411, 5171, '05/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (294, 391, 5258, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (295, 59, 5171, '19/04/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (296, 59, 5171, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (297, 238, 26694710, '01/03/2021', '19/04/2021', 1);
INSERT INTO `prestamos` VALUES (298, 238, 26694710, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (299, 375, 26694683, '01/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (300, 20, 26694705, '20/04/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (301, 27, 26694705, '01/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (302, 371, 26694696, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (303, 25, 26694696, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (304, 39, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (305, 82, 5127, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (306, 85, 5137, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (307, 85, 5137, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (308, 85, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (309, 389, 26694687, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (310, 21, 5348, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (311, 27, 5137, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (312, 69, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (313, 371, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (314, 371, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (315, 67, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (316, 31, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (317, 95, 5532, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (318, 70, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (319, 409, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (320, 450, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (322, 79, 5187, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (323, 129, 5560, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (324, 371, 26694705, '20/04/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (325, 29, 26694705, '05/03/2021', '20/04/2021', 1);
INSERT INTO `prestamos` VALUES (326, 371, 26694705, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (327, 22, 26694711, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (328, 33, 26694719, '19/04/2021', '19/05/2021', 1);
INSERT INTO `prestamos` VALUES (329, 29, 26694714, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (330, 36, 26694716, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (331, 35, 26694712, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (332, 32, 26694713, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (333, 34, 26694717, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (334, 23, 26694718, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (335, 15, 26694720, '19/04/2021', '', 0);
INSERT INTO `prestamos` VALUES (336, 27, 26694721, '19/04/2020', '', 0);
INSERT INTO `prestamos` VALUES (337, 42, 26694731, '06/05/2021', '06/05/2021', 1);
INSERT INTO `prestamos` VALUES (338, 42, 26694722, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (339, 25, 26694723, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (340, 20, 26694724, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (341, 26, 26694725, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (342, 24, 26694726, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (343, 21, 26694727, '06/05/2021', '14/05/2021', 1);
INSERT INTO `prestamos` VALUES (344, 39, 26694728, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (345, 85, 26694729, '06/05/2021', '19/05/2021', 1);
INSERT INTO `prestamos` VALUES (346, 17, 26694730, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (347, 58, 26694734, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (348, 62, 26694735, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (349, 51, 26694736, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (350, 68, 26694737, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (351, 463, 26694738, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (352, 43, 26694739, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (353, 48, 26694740, '06/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (354, 465, 26694731, '05/03/2021', '', 0);
INSERT INTO `prestamos` VALUES (355, 64, 5165, '14/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (356, 18, 26694727, '14/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (357, 77, 5125, '19/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (358, 73, 5144, '19/05/2021', '', 0);
INSERT INTO `prestamos` VALUES (359, 75, 5155, '19/05/2021', '', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `roles`
-- 

CREATE TABLE `roles` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) default NULL,
  `descripcion` varchar(100) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `nombre_UNIQUE` (`nombre`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `roles`
-- 

INSERT INTO `roles` VALUES (1, 'superadmin', NULL);
INSERT INTO `roles` VALUES (2, 'admin', NULL);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipolector`
-- 

CREATE TABLE `tipolector` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `tipolector`
-- 

INSERT INTO `tipolector` VALUES (1, 'Ejecutivo');
INSERT INTO `tipolector` VALUES (2, 'Jefatura');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipousuario`
-- 

CREATE TABLE `tipousuario` (
  `id` int(11) NOT NULL auto_increment,
  `denominacion` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `tipousuario`
-- 

INSERT INTO `tipousuario` VALUES (1, 'Administrador');
INSERT INTO `tipousuario` VALUES (2, 'Usuario');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `dni` varchar(10) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass_usuario` varchar(150) NOT NULL,
  `rol_id` int(11) NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'yony brondy', 'mamani fuentes', '45454545', '343434', 'yony@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0);
INSERT INTO `usuarios` VALUES (3, 'Javier', 'Oyanader', '18979626', '971836195', 'j.oyanaderbascur@gmail.com', '5e612fbcf98d8452ce474c972941439d', 0);
INSERT INTO `usuarios` VALUES (4, 'Giobi', 'Oayander', '18979627', '', 'javier@javier.cl', '6a7c2176157063c999454180f4ca596a', 0);
INSERT INTO `usuarios` VALUES (5, 'Javier1', 'Oya', '12345678', '', 'j.oyanaderbascur2@gmail.com', '5e612fbcf98d8452ce474c972941439d', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios1`
-- 

CREATE TABLE `usuarios1` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `nombres` varchar(100) default NULL,
  `apellidos` varchar(100) default NULL,
  `telefono` varchar(20) default NULL,
  `email` varchar(100) default NULL,
  `username` varchar(45) default NULL,
  `password` varchar(100) default NULL,
  `rol_id` int(11) default NULL,
  `estado` tinyint(1) default NULL,
  PRIMARY KEY  (`id_usuario`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `fk_rol_usuarios_idx` (`rol_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- 
-- Volcar la base de datos para la tabla `usuarios1`
-- 

INSERT INTO `usuarios1` VALUES (2, 'Juan Carlos ', 'Perez Maldonado', '454545', 'juancarlos@gmail.com', 'juancito17', NULL, 1, 0);
INSERT INTO `usuarios1` VALUES (3, 'Javier Ignacio', 'Oyanader Bascur', '971836195', 'j.oyanaderbascur@gmail.com', 'joyanaderb', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 2, 1);
INSERT INTO `usuarios1` VALUES (5, 'Javier Ignacio', 'Oyanader Bascur', '971836195', 'j.oyanaderbascur2@gmai.com', 'joyanaderb2', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 1, NULL);
INSERT INTO `usuarios1` VALUES (7, 'Javier', 'Oyanader', '971836195', 'j.oyanaderbascur5@gmail.com', NULL, 'a94e3d4848c846b4202d8e152b425c6d', 2, NULL);
INSERT INTO `usuarios1` VALUES (8, 'Javier', 'Oyanader', '971836195', 'djtoushfacebook@hotmail.com', NULL, '7ddf2259be56e0c5381ec7727e548a93', 1, 1);
INSERT INTO `usuarios1` VALUES (12, 'Simon', 'Campos', '111111111', 'scamposm@ripley.com', 'Scamposm', '15e11e26dc5e1e3aa6b082ac9a1fb475e6d42389', 1, 1);
INSERT INTO `usuarios1` VALUES (13, 'Giovani', 'Vega', '99999999', 'gvegac@ripley.com', 'Gvegac', '15e11e26dc5e1e3aa6b082ac9a1fb475e6d42389', 1, 1);
INSERT INTO `usuarios1` VALUES (14, 'Seguridad ', 'Ccr', '99999999', 'joyanaderb@ripley.com', 'Seguridadccr', '15e11e26dc5e1e3aa6b082ac9a1fb475e6d42389', 2, 1);
INSERT INTO `usuarios1` VALUES (15, 'Karen', 'Moreno', '99999999', 'kmorenoc@ripley.com', 'Kmorenoc', '7c794f962149bd7ab496504fb9b3307b766fd571', 2, 1);
INSERT INTO `usuarios1` VALUES (16, 'Edison ', 'Cabrera', '99999999', 'ecabrera@ripley.com', 'Ecabrera', '7c794f962149bd7ab496504fb9b3307b766fd571', 2, 1);
INSERT INTO `usuarios1` VALUES (17, 'Cristian ', 'Wyman', '99999999', 'cwymanf@ripley.com', 'Cwymanf', '15e11e26dc5e1e3aa6b082ac9a1fb475e6d42389', 1, 1);
INSERT INTO `usuarios1` VALUES (18, 'Maria', 'Rojas', '11111111', 'merojas@ripley.com', 'Merojas', '7c794f962149bd7ab496504fb9b3307b766fd571', 2, 1);
INSERT INTO `usuarios1` VALUES (19, 'Evelyne ', 'Castillo Silva', '999999999', 'ecastillos@ripley.com', 'ecastillos', '7c794f962149bd7ab496504fb9b3307b766fd571', 2, 1);

-- --------------------------------------------------------

-- 
-- Estructura para la vista `equiposdisponibles`
-- 
DROP TABLE IF EXISTS `equiposdisponibles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `inventarioequipos`.`equiposdisponibles` AS select count(0) AS `total` from `inventarioequipos`.`libros` where ((`inventarioequipos`.`libros`.`ejemplares_libro` = 1) and (`inventarioequipos`.`libros`.`prestados_libro` = 0));
