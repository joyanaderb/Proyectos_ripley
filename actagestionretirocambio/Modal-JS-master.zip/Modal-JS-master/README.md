# Modal-JS
## On pure JavaScript
![Screenshot](https://github.com/botyk/Modal-JS/blob/master/screenshot.png)
